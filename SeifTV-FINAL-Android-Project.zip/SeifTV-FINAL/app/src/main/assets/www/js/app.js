const shows=[
 {id:1,title:"ليالي المدينة",cat:"عربي",type:"دراما",year:"2026",img:"assets/seif-tv-icon.png"},
 {id:2,title:"الطريق الأخير",cat:"تركي",type:"دراما",year:"2026",img:"assets/seif-tv-icon.png"},
 {id:3,title:"وقت الضحك",cat:"أجنبي",type:"كوميدي",year:"2026",img:"assets/seif-tv-icon.png"},
 {id:4,title:"الحكاية الجديدة",cat:"عربي",type:"دراما",year:"2026",img:"assets/seif-tv-icon.png"}
];
const favs=JSON.parse(localStorage.getItem("seif_favs")||"[]");
function card(s){const on=favs.includes(s.id);return `<article class="card"><button class="fav ${on?'on':''}" onclick="toggleFav(${s.id})">${on?'♥':'♡'}</button><div class="poster" style="background-image:url('${s.img}')"></div><div class="card-body"><div class="card-title">${s.title}</div><div class="meta">${s.cat} • ${s.type} • ${s.year}</div></div></article>`}
function render(){document.querySelector("#latestCards").innerHTML=shows.map(card).join(""); const c=shows.filter(x=>localStorage.getItem("continue_"+x.id)); document.querySelector("#continueCards").innerHTML=c.length?c.map(card).join(""):"<div class='meta'>لم تبدأ مشاهدة أي محتوى بعد.</div>"}
function toggleFav(id){const i=favs.indexOf(id);if(i>=0)favs.splice(i,1);else favs.push(id);localStorage.setItem("seif_favs",JSON.stringify(favs));render()}
function filterCat(cat){const a=shows.filter(s=>s.cat===cat||s.type===cat);document.querySelector("#latestCards").innerHTML=(a.length?a:shows).map(card).join("");document.querySelector("#latest").scrollIntoView({behavior:"smooth"})}
function showAll(){document.querySelector("#latestCards").innerHTML=shows.map(card).join("")}
function openSearch(){document.querySelector("#searchModal").classList.remove("hidden");document.querySelector("#searchInput").focus()}
function closeSearch(){document.querySelector("#searchModal").classList.add("hidden")}
function doSearch(){const q=document.querySelector("#searchInput").value.trim().toLowerCase();const a=shows.filter(s=>s.title.toLowerCase().includes(q));document.querySelector("#searchResults").innerHTML=a.map(card).join("")||"<div class='meta'>لا توجد نتائج.</div>"}
document.querySelector("#searchBtn").onclick=openSearch;document.querySelector("#navSearch").onclick=openSearch;render();
